package Order;

public class asd { 
    public static int i=0;
    public static int id=0;
    public static int login_flag=0;
    public static int reg_flag=0;
    public static int mode=0;
    public static int smode=0;  
    public static int re=0;
    public static String username="";
    public static int user=0;
    public static int mpizza=0;
    public static int bill=0;
}
